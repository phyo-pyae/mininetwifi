in this testbed the vehicle speed is changing over time and 
more generalized in code
